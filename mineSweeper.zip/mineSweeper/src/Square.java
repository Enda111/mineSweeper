
public class Square {
    public int adjacentBombs;
    public boolean bomb;
    public boolean open;
    public boolean flagged;
    public String groundS = "\u25A9";
    public String holeS = "\u25A1";
    public String bombS = "\u25CE";
    public String flagS = "\u2691";


    public String symbol = groundS;
    public String spacer = " ";

    public Square()
    {
    }

    public void setBomb(boolean b)
    {
        bomb = b;
    }

    public boolean getBomb()
    {
        return bomb;
    }

    public void setAdjacentBombs(int adj)
    {
        adjacentBombs = adj;
    }

    public void setFlagged()
    {
        flagged = true;
        symbol = flagS;
    }

    public void setUnFlagged()
    {
        if (flagged)
        {
            flagged = false;
            symbol = groundS;
        }
        else {
            System.out.println("Sorry this space is not flagged.\nYou can either add a flag or pick another location.");
        }

    }

    public void setOpen(boolean b)
    {
        open = true;
        if (b)
        {
            symbol = bombS;

        }
        else
        {
            if (adjacentBombs==0)symbol = holeS;
            else symbol = "" + adjacentBombs;
        }
    }



    public void display()
    {
        System.out.print(symbol + spacer);
    }



}
