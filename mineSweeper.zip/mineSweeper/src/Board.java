import java.util.Random;

public class Board {

    public int size;
    Square[][] board;
    public boolean alive = true;
    public Board(int s, Random r) {
        size = s;
        board = genBoard(size, r);
    }

    public Square[][] genBoard(int s, Random r) {
        int bombsLeft = s;

        Square[][] board = new Square[s][s];
        for(int x = 0; x < s; x++)
        {
            for(int y = 0; y < s; y++)
            {
                board[x][y] = new Square();
                if(bombsLeft>=0)
                {
                    if(r.nextInt(0, bombsLeft) == 1) {
                        board[x][y].setBomb(true);
                        bombsLeft--;
                    }
                }
                else
                {
                    board[x][y].setBomb(false);
                }
            }
        }


        for (int x = 0; x < s; x++)
        {
            for(int y = 0; y < s; y++)
            {
                int value = 0;
                for (int i = -1; i < 2; i++)
                {
                    if((x+i)>=0 && (x+i)<s)
                    {
                        for (int j = -1; j < 2; j++) {
                            if((y+j)>=0 && (y+j)<s)
                            {
                                if(board[x+i][y+j].getBomb())
                                {
                                    value++;
                                }
                            }
                        }
                    }
                }
                board[x][y].setAdjacentBombs(value);
            }
        }

        return board;
    }

    public void showBoard() {
        System.out.print(ANSI.ANSI_WHITE_BACKGROUND+ANSI.ANSI_BOLD);
        System.out.print("  +  ");
        for (int i = 0; i < size; i++) System.out.print("+ ");
        System.out.print(" +  ");
        System.out.println(ANSI.ANSI_RESET);
        boolean rEven = true;
        boolean cEven;

        for(Square[] row : board)
        {
            System.out.print(ANSI.ANSI_WHITE_BACKGROUND+ANSI.ANSI_BOLD+"  + "+ANSI.ANSI_RESET);
            if(rEven) System.out.print(ANSI.ANSI_DGREEN_BACKGROUND);
            else System.out.print(ANSI.ANSI_LGREEN_BACKGROUND);
            System.out.print(" ");

            cEven = true;
            for(Square unit : row)
            {
                if(cEven) System.out.print(ANSI.ANSI_YELLOW+ANSI.ANSI_BOLD);
                else System.out.print(ANSI.ANSI_DRED+ANSI.ANSI_BOLD);
                unit.display();
                cEven=!cEven;
            }
            System.out.print(ANSI.ANSI_RESET);
            System.out.print(ANSI.ANSI_WHITE_BACKGROUND+ANSI.ANSI_BOLD+" +  "+ANSI.ANSI_RESET);
            System.out.println();
            rEven=!rEven;
        }
        System.out.print(ANSI.ANSI_WHITE_BACKGROUND + ANSI.ANSI_BOLD);
        System.out.print("  +  ");
        for (int i = 0; i < size; i++) System.out.print("+ ");
        System.out.print(" +  ");
        System.out.println(ANSI.ANSI_RESET);

    }

    public void dig(int x, int y) {

        if (board[x][y].flagged)
        {
            System.out.println("Sorry this space has been flagged.\nYou can either remove the flag or pick another location.");
        }
        else {
            board[x][y].setOpen(board[x][y].getBomb());
            if (board[x][y].getBomb()) alive = false;
            else {

                for (int i = x - 1; i < x + 2; i++) {
                    if ((i) >= 0 && (i) < size) {
                        for (int j = y - 1; j < y + 2; j++) {
                            if ((j) >= 0 && (j) < size) {
                                if ((i != x && j == y) || (j != y && i == x)) {


                                    if (!board[i][j].getBomb() && !board[i][j].open && board[i][j].adjacentBombs == 0) {
                                        dig(i, j);
                                        for (int ai = i - 1; ai < i + 2; ai++) {
                                            if ((ai) >= 0 && (ai) < size) {
                                                for (int aj = j - 1; aj < j + 2; aj++) {
                                                    if ((aj) >= 0 && (aj) < size) {
                                                        if (!board[ai][aj].getBomb() && !board[ai][aj].open) {
                                                            digOne(ai, aj);
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                    }
                                }


                            }
                        }
                    }

                }
            }
        }
    }

    public void digOne(int x, int y) {
        board[x][y].setOpen(board[x][y].getBomb());
        if (board[x][y].getBomb()) alive = false;
    }
    public boolean isAlive() {
        return alive;
    }
}
