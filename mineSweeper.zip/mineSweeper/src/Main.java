import java.util.Random;
import java.util.Scanner;
import java.io.IOException;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import java.awt.GraphicsEnvironment;
import java.net.URISyntaxException;

public class Main {

    public static void main(String[] args) throws IOException {
//        String title = "My Console Window";
//        String command = "java -jar myapplication.jar";

        // Use platform-specific commands to create a new console window
        String osName = System.getProperty("os.name").toLowerCase();
        String[] cmd;
        if (osName.contains("mac")) {
            cmd = new String[]{"/bin/sh", "-c", "open -a Terminal.app && java -jar Game.jar"};
        } else {
            throw new UnsupportedOperationException("Unsupported operating system: " + osName);
        }

        // Execute the command and set the console window title
        Runtime rt = Runtime.getRuntime();
        Process pr = rt.exec(cmd);
        if (osName.contains("mac")) {
            // Do nothing, since the Terminal window title cannot be set via command line
        }

        // Wait for the process to complete
        try {
            pr.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}