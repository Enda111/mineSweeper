import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Random;
import java.util.Scanner;

public class Game {

    public static Board b;
    public static int size;

    public static void game (String [] args) throws IOException, InterruptedException, URISyntaxException {


        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        System.out.println("What size would you like? ");
        size = input.nextInt();

        b = new Board(size, rand);

        boolean quit = false;
        ANSI.clearScreen();
        do
        {
            ANSI.clearScreen();
            playTurn();

            int x = input.nextInt() - 1;
            int y = input.nextInt() - 1;
            String a = input.next();

            if (a.equals("d"))
            {
                b.dig(x,y);
                if(!b.isAlive())
                {
                    quit = true;
                }
            } else if (a.equals("f"))
            {
                b.board[x][y].setFlagged();
            } else if (a.equals("r"))
            {
                b.board[x][y].setUnFlagged();
            }

            System.out.println("\n");

            if (quit)
            {
                System.out.println("BOOM!!!\nYou died");
            }

        } while (!quit);

    }

    public static void playTurn(){
        ANSI.clearScreen();
        System.out.println("\nPlease enter coordinates and action \n *  1 - "+size+" by 1 - "+size+", \n *  d - dig\n *  f - flag\n *  r - remove flag\n *  format: x y a");
        b.showBoard();
    }



}
