
public class ANSI {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_DRED = "\u001B[31m";
    public static final String ANSI_LRED = "\u001B[91m";
    public static final String ANSI_DGREEN = "\u001B[32m";
    public static final String ANSI_LGREEN = "\u001B[92m";
    public static final String ANSI_YELLOW = "\u001B[93m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";

    public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_DGREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_LGREEN_BACKGROUND = "\u001B[102m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
    public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";

    public static final String ANSI_BOLD = "\u001B[1m";
    public static final String ANSI_UL = "\u001B[4m";
    public static final String ANSI_NUL = "\u001B[24m";

    public static void clearScreen() {
        System.out.print("\u001B[H \u001B[2J");
        System.out.flush();
    }

}
